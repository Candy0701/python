'''
你設計了一個函式計算並顯示從2到9的所有乘法組合的九九乘法表。
你要如何完成這段程式碼?
請在回答區選擇適當的程式碼片段。

#九九乘法表函式
def times_tables():
    __(1)__
        __(2)__
            print(row * col, end = " ")
        print()

#呼叫九九乘法表
times_tables()

()(1) 
A. for col in range(9):
B. for col in range(2,10):
C. for col in range(2,9,1):
D. for col in range(10):
( )(2) 
A. for row in range(9):
B. for row in range(2,9,1):
C. for row in range(2,10):
D. for row in range(10):
'''