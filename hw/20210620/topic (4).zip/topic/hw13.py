'''
公司正在將過去的進銷存程式碼轉移到 Python,
以下哪個是正確的語法?

()A.
//返回公司帳户的目前營業額
def get_saletotal():
    return saletotal

()B.
/*返回公司帳戶的目前營業额*/
def get_saletotal():
    return saletotal

()C.
'返回公司帳戶的目前營業额
def get_saletotal():
    return saletotal

()D. 
#返回公司帳戶的日前業额
def get_saletotal():
    return saletotal
'''