'''
5. 你正在設計一個線上遊戲記分的python應用程式。
需要符合以下條件的函式:
1. 函式名為calc_score
2. 函式接收二個參數:目前分數和一個值
3. 函式將值增加到目前分數
4. 函式返回新分數
你要如何完成程式碼?請在回答區中選擇當的程式碼片段。
__(1)__ __(2)__
    current += value
__(3)__

( )(1) 
A. calc_score 
B. def calc_score
C. return calc_score
( )(2) 
A. (current, value): 
B. ():
C. (current, value) 
D. ()
( )(3) 
A. pass current
B. return current
C. return
D. pass
'''