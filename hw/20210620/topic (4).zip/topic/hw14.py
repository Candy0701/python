'''
你設計一個函式,使用Python 計算矩形的面積。
在函式中有加入注釋，程式碼如下:

01 # area_rectangle 函式計算矩形面積
02 # x是長
03 # y是寬
04 # 返回 x*y 的值
05 def area_retangle(x, y):
06  comment = "# 返回值"
07  return x*y # x*y
針對下列每個敘述,如果是正確的就選擇Yes,否請選擇o
A.01到04行在語法檢查時將被忽略。
( )Yes ( )No

B.02和03行中的井宇符號(#)非必填的。
( )Yes( )No

C.06行中的宇串將被解釋為注釋
()Yes ( )No

D.07行包含內嵌注釋。
()Yes ( )No
'''