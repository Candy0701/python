'''
你正在開發一個補習班的Python程式來計算折扣,
補習班希望鼓勵小朋友和老年人報名,
只要是小朋友和老年人報名相關課程就會獲得10%的折扣。
你編寫了以下程式碼:
01 def get_discount(kid, senior):
02  discount = 0.1
03
04      discount = 0
05  return discount
為了完成這個程式碼,你應該在03行加入什麼程式碼?
( )A. if not (kid or senior):
( )B. if (not kid) or senior;
( )C. if not (kid and senior):
( )D. if (not kid) and senior;
'''