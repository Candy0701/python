'''
你設計一個python應用程式，需將資料讀寫到文字檔中。
如果檔案不存在，則必須新增它。
如果檔案已有內容,則將文字加到最後。
你該使用哪個程式碼?
( )A. open("file_data", "a")
( )B. open("file_data", "w")
( )c. open("file_data", "r+")
( )D. open("file_data", "r")
'''