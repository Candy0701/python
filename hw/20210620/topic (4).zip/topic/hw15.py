'''
一家運動器材公司正在設計一個程式用來記錄客戶跑步時的距離,
你設計以下的Python程式碼:
01
02  name = input("請输入你的姓名。")
03  return name
04
05  calories = kms * calories_per_km
07  return calories
08 distance=int(input(”你造理了幾公里?")
09 burn_rate = 80
10 runner = get_name()
11 calories_burned = calc_calories(distance, burn_rate)
12 print(runner, ",你燃燒了大約", calores_burned, "卡路里。")
在程式中必須要定義二個必要的函式。
你將在01及04行中使用那些程式碼片段?
( )A. 01 def get_name():
( )B. 01 def get_name(runner):
( )C. 01 def get_name(name):
( )D. 04 def calc_calories():
( )E. 04 def calc_calories(kms, burn_rate):
( )F. 04 def calc_calories(kms, calories_per_km):
'''