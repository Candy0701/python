'''
同事開發一個將產品名稱輸入到資料庫的程式,但是其中發生了錯誤,
每個存入的名稱字母順序都顛倒了。請你開發一個Python程式,
將每個產品名稱以正確的順序輸出。
請選擇適當的程式碼片段來完成程式:

#函式會反轉字串中的字元。
#以相反的順序返回新字串。
def reverse_pname(backwards_pname):
    forward_pname = ''
    for index in __(1)__
        forward_pname += __(2)__
    return forward_pname

print(reverse_pname("klim”))# 測诚範例


()(1) 
A.backwards_pname 
B.len(backwards_pname)
C.range(0,len(backwards_pname),-1)
D.range(len(backwards_pname)-1,-1,-1)
()(2) 
A.backwards_pname[index-1]
B.backwards_pname[len(forward_pname)-1) 
C.backwards_pname[len(backward_name)-len(forward_pname)]
D.backwards_pname[index]
'''
