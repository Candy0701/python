'''
你正在設計一個處理數字的函式。該函式具有以下要求:
1. 將浮點數傳遞到函式中
2. 函式必須取浮點數的絕對值
3· 函式必須無條件進位到整數
你應該使用哪兩個數學函式?
( )A. math.fabs(x)
( )B. math.floor(x)
( )C. math.fmod(x)
( )D. math.ceil(x)
( )E. math.frexp(x)
'''