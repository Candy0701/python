'''
在下列的語法敘述中,如果是正確的就選擇Yes,否則請選擇No。

A. 在try語法中可以有不只一個except子句。
( )Yes ( )No

B. 在try語法中可以不加except子句
( )Yes ( )No

C. 在try語法中可以有一個finally子句典except子句
( )Yes ( )No

D. 在try語法中可以有不只一個finally子句
( )Yes ( )No
'''