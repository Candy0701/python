'''
你製作一個程式詢問使用者家中有多少個小孩,
使用者必須輸入整數,如果輸入值不是整數,
程式碼必須指出並要求重新輸入。
你要如何完成程式碼?
請在回答區中選擇適當的程式碼片段。
while True:
    __(1)__
        x=int(input("請問您有個小孩:"))
        break
    __(2)__ Valueerror:
        print("請確認您输入的是一個整數,請再試一次···")
( )(1)A. try: B. else: C. except: D. raise: E. finally:
( )(2)A. try B. else C. except D, raise E. finally
'''