'''
你正在編寫一個函式來判別負數與非負數。這個函式必須符合以下要求:
1. 如果 a 是負數,則回傳"值是負數"
2. 如果 a 不是負數,則為非負數,再繼續判別。
3. 如果 a 大於0, 則回傳"值是正數",否則回傅"值是零"
你要如何完成這段程式碼?請在回答區選擇適當的程式碼片段。
def reResult(a):
    (1)
        answer="值是負数"
    (2)
        (3)
            answer ="值是正数"
        (4)
            answer="值是零"
    return answer

()(1) A. if a < 0: B. if a > 0: C. else: D. elif:
()(2) A. if a < 0: B. if a > 0: C. else: D. elif:
()(3) A. if a < 0: B. if a > 0: C. else: D. elif:
()(4) A. if a < 0: B. if a > 0: C. else: D. elif:
'''